<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Entity\Task;
use App\Form\TaskType;
use Symfony\Component\HttpFoundation\Request;

class AppController extends AbstractController
{

    public function listTasks()
    {
        $em = $this->getDoctrine()->getManager();
        $tasks = $em->getRepository(Task::class)->findAll();
        return $this->render('app/list_tasks.html.twig', [
            'tasks' => $tasks
        ]);
    }

    public function addTask(Request $request)
    {
        $task = new Task();
        $task->setDone(0);
        $form = $this->createForm(TaskType::class, $task);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $task = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist($task);
            $em->flush();
            return $this->redirectToRoute('list_tasks');
        }

        return $this->render('app/form_task.html.twig', [
            'form' => $form->createView()
        ]);
    }

    public function editTask(Request $request, $slug)
    {
        $em = $this->getDoctrine()->getManager();
        $task = $em->getRepository(Task::class)->findOneBy(['slug' => $slug]);
        $form = $this->createForm(TaskType::class, $task);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $task = $form->getData();
            $em->persist($task);
            $em->flush();
            return $this->redirectToRoute('list_tasks');
        }

        return $this->render('app/form_task.html.twig', [
            'form' => $form->createView()
        ]);
    }

    public function deleteTask($slug) {
        $em = $this->getDoctrine()->getManager();
        $task = $em->getRepository(Task::class)->findOneBy(['slug' => $slug]);
        $em->remove($task);
        $em->flush();
        return $this->redirectToRoute('list_tasks');
    }

}
