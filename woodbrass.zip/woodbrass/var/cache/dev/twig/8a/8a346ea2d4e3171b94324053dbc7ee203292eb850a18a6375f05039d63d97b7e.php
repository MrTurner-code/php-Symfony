<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* app/contact.html.twig */
class __TwigTemplate_e9838ebe4ce85aa1cdb5f229f1c1d579c7e465a029a2c3b0eeb0f02320c700a5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/contact.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/contact.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "app/contact.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " | Contact";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <h1>Contact</h1>

    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur accumsan semper dui non tempus. Nullam felis odio, vulputate eu dignissim quis, sodales non diam. Fusce hendrerit varius dictum. Vivamus faucibus sem malesuada placerat commodo. Donec euismod lacinia porta. Nullam quis dictum neque. Donec rutrum odio sagittis odio luctus maximus.
    </p>
    <p>
      Donec tristique auctor nibh, nec elementum elit consequat nec. Vivamus mattis sed ipsum vel dapibus. Etiam et dictum quam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nisl mi, pharetra quis dignissim eu, aliquam eu elit. Pellentesque quis fermentum augue, quis maximus lectus. Nullam elementum massa ut mi congue, vitae sodales purus euismod. Aenean turpis mauris, sollicitudin et euismod nec, accumsan viverra elit. Donec magna purus, vulputate quis urna eget, rutrum pharetra tellus. Donec hendrerit augue a turpis venenatis, vel porta mauris vestibulum. Ut ultricies dolor purus, in fermentum est dictum a. 
  </p>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "app/contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 6,  79 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}{{ parent() }} | Contact{% endblock %}

{% block body %}
    <h1>Contact</h1>

    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur accumsan semper dui non tempus. Nullam felis odio, vulputate eu dignissim quis, sodales non diam. Fusce hendrerit varius dictum. Vivamus faucibus sem malesuada placerat commodo. Donec euismod lacinia porta. Nullam quis dictum neque. Donec rutrum odio sagittis odio luctus maximus.
    </p>
    <p>
      Donec tristique auctor nibh, nec elementum elit consequat nec. Vivamus mattis sed ipsum vel dapibus. Etiam et dictum quam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nisl mi, pharetra quis dignissim eu, aliquam eu elit. Pellentesque quis fermentum augue, quis maximus lectus. Nullam elementum massa ut mi congue, vitae sodales purus euismod. Aenean turpis mauris, sollicitudin et euismod nec, accumsan viverra elit. Donec magna purus, vulputate quis urna eget, rutrum pharetra tellus. Donec hendrerit augue a turpis venenatis, vel porta mauris vestibulum. Ut ultricies dolor purus, in fermentum est dictum a. 
  </p>
{% endblock %}", "app/contact.html.twig", "C:\\Users\\thiba\\OneDrive\\Documents\\Symfony\\woodbrass\\templates\\app\\contact.html.twig");
    }
}
